var today = new Date();
var hourNow = today.getHours();
var greeting;
if(hourNow>=18) {
	greeting='Good Evning';

}else if (hourNow>=12){
	greeting='Good Afternoon';
}else if (hourNow>4){
	greeting='Good Morning';
} else{
	greeting='Get some sleep!';
}
document.write(greeting);

